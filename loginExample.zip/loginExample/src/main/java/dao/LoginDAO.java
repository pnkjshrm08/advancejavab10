package dao;

public class LoginDAO {
	
	public boolean authenticateUser(String userName, String pass) {
		
		
		
		return true;
		
		
	}

}
